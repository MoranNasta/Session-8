const express = require("express");
const app = express();
var cors = require('cors')
const PORT = process.env.PORT || 3030;


// var bodyParser = require('body-parser'); 
// var urlencodedParser = bodyParser.urlencoded({ extended: false })  

app.use(express.json());
// your code
app.use(cors())

app.get('/',(req,res)=>{
    res.send('Hi All');
})

app.get('/data',(req,res)=>{
    var data = ['Ali beik','Georgio','Ahmad','Rym']
    res.send(data);
})

app.post('/SaveUser',(req,res)=>{
    console.log(req.body)
    res.send('Ok Mishi El 7al')
})

app.post('/Login',(req,res)=>{
    console.log(req.body);
    if ((req.body.username == 'ALI') && (req.body.pwd == 'RIZK')){
        res.send(true);
    }
    else
    {
        res.send(false);
    }
})


app.listen(PORT, () => {
  console.log(`server started on port ${PORT}`);
});